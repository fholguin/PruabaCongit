require 'test_helper'

class MeetingsHelperTest < ActionView::TestCase
end
