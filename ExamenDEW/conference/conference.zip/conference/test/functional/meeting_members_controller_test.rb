require 'test_helper'

class MeetingMembersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
