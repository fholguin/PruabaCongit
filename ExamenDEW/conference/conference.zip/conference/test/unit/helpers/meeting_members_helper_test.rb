require 'test_helper'

class MeetingMembersHelperTest < ActionView::TestCase
end
